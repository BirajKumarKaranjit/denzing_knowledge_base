import re
from collections import defaultdict
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed
import pyodbc
import struct
from itertools import chain, repeat
from azure.identity import ClientSecretCredential

import pandas as pd

from itlm_db_connector.connection_pool import ConnectionPool
from itlm_db_connector.utils.custom_exception import (
    DatabaseConnectionError,
    QueryExecutionError,
)

MSFABRIC_QUERY_TIMEOUT_SEC = 30
MSFABRIC_SAMPLE_ROWS = 3

MSFABRIC_ERROR_MESSAGE = {
    "Connection_error": "ERR_NO_CONNECTION_CONFIG: Missing required connection configuration for Microsoft Fabric",
    "Invalid_endpoint_error": "ERR_ENDPOINT_INVALID: Connection test failed for Microsoft Fabric",
    "Authentication_error": "ERR_AUTH_FAILED: Authentication failed",
    "Permission_error": "ERR_FABRIC_PERMISSION: Insufficient permissions.",
    "SQL_syntax_error": "ERR_SQL_SYNTAX: Syntax error in query.",
    "Query_timeout_error": "ERR_QUERY_TIMEOUT: Query execution timed out.",
    "Unknown_Error": "ERR_UNKNOWN_FABRIC: Unknown Microsoft Fabric error",
    "Table_not_found_error": "Table not found in the database.",
    "Table_fetching_data_error": "Error fetching table data",
    "Sample_rows_error": "Error getting sample rows",
    "DDL_error": "Error getting DDL",
    "Value_error": "Invalid identifier",
}


class MicrosoftFabric:
    """
    Configuration values for connecting to Microsoft Fabric SQL endpoints.

    Attributes
    dialect : str
        The SQL dialect identifier used by the engine/ORM.

    RESOURCE_URL : str
        The Azure Active Directory resource (scope) used when requesting an
        access token for Microsoft Fabric.

    SQL_DRIVER : str
        The ODBC driver used to establish secure connections to Microsoft
        Fabric SQL endpoints. We use "ODBC Driver 18 for SQL Server" because
        it is the supported, secure driver installed on the server where our
        application runs.
    """

    dialect = "microsoftfabric"
    RESOURCE_URL = "https://database.windows.net/.default"
    SQL_DRIVER = "ODBC Driver 18 for SQL Server"

    def __init__(
        self,
        **kwargs,
    ) -> None:
        """
        Initialize the Microsoft Fabric connector object using kwargs.

        kwargs can include:
            - role (maps to tenant_id)
            - username (maps to client_id)
            - password (maps to client_secret)
            - host (maps to sql_endpoint)
            - database (maps to database)
            - schema (maps to schema)
            - query_timeout
            - no_of_sample_rows
        """
        if not (
            kwargs.get("username")
            and kwargs.get("password")
            and kwargs.get("role")
            and kwargs.get("host")
        ):
            raise DatabaseConnectionError(MSFABRIC_ERROR_MESSAGE["Connection_error"])

        self.client_id = kwargs.get("username")
        self.client_secret = kwargs.get("password")
        self.tenant_id = kwargs.get("role")
        self.sql_endpoint = kwargs.get("host")
        self.resource_url = self.RESOURCE_URL
        self.sql_driver = self.SQL_DRIVER
        self.database = kwargs.get("database")
        self.schema = kwargs.get("schema")
        self.query_timeout = kwargs.get("query_timeout", MSFABRIC_QUERY_TIMEOUT_SEC)
        self.no_of_sample_rows = kwargs.get("no_of_sample_rows", MSFABRIC_SAMPLE_ROWS)

        if self.database:
            self._validate_identifier(self.database)
        if self.schema:
            self._validate_identifier(self.schema)

    @staticmethod
    def _validate_identifier(name):
        identifier = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
        if not identifier.match(name):
            raise ValueError(f"{MSFABRIC_ERROR_MESSAGE['Value_error']}: {name}")
        return name

    def create_connection(self):
        """
        Establish and return a connection to Microsoft Fabric using OAuth2 Service Principal.
        Executes a simple test query to validate the connection.

        Raises:
            DatabaseConnectionError with specific error codes:
                ERR_AUTH_FAILED
                ERR_ENDPOINT_INVALID
                ERR_UNKNOWN_FABRIC

        Returns:
            pyodbc.Connection: Authenticated connection object.
        """
        try:
            credential = ClientSecretCredential(
                tenant_id=self.tenant_id,
                client_id=self.client_id,
                client_secret=self.client_secret,
            )
            token_object = credential.get_token(self.resource_url)
            token_as_bytes = bytes(token_object.token, "UTF-8")

            encoded_bytes = bytes(chain.from_iterable(zip(token_as_bytes, repeat(0))))
            token_bytes = struct.pack("<i", len(encoded_bytes)) + encoded_bytes
            SQL_COPT_SS_ACCESS_TOKEN = 1256
            attrs_before = {SQL_COPT_SS_ACCESS_TOKEN: token_bytes}

            conn_str = (
                f"Driver={self.sql_driver};"
                f"Server={self.sql_endpoint};"
                f"Database={self.database};"
                f"Schema={self.schema};"
                f"Encrypt=yes;"
                f"TrustServerCertificate=no;"
            )

            connection = pyodbc.connect(
                conn_str, attrs_before=attrs_before, timeout=self.query_timeout
            )

            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
                result = cursor.fetchone()
                if not result or result[0] != 1:
                    connection.close()
                    raise DatabaseConnectionError(
                        MSFABRIC_ERROR_MESSAGE["Invalid_endpoint_error"]
                    )

            return connection

        except Exception as e:
            error_str = str(e).lower()

            auth_keywords = ["authentication", "credential", "unauthorized"]
            endpoint_keywords = ["endpoint", "server", "connection"]

            if any(k in error_str for k in auth_keywords):
                raise DatabaseConnectionError(
                    f"{MSFABRIC_ERROR_MESSAGE['Authentication_error']}: {e}"
                )
            elif any(k in error_str for k in endpoint_keywords):
                raise DatabaseConnectionError(
                    f"{MSFABRIC_ERROR_MESSAGE['Invalid_endpoint_error']}: {e}"
                )
            else:
                raise DatabaseConnectionError(
                    f"{MSFABRIC_ERROR_MESSAGE['Unknown_Error']}: {e}"
                )

    def execute_query(self, query: str):
        """
        Execute the SQL query on the Microsoft Fabric database.
        :param query: The SQL query to execute.
        :returns: pandas.DataFrame
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                with connection.cursor() as cursor:
                    cursor.execute(query)
                    rows = cursor.fetchall()
                    columns = (
                        [col[0] for col in cursor.description]
                        if cursor.description
                        else []
                    )
                    if rows and columns:
                        tuple_rows = [
                            tuple(
                                row[i] if i < len(row) else None
                                for i in range(len(columns))
                            )
                            for row in rows
                        ]
                    else:
                        tuple_rows = rows
                    return pd.DataFrame(tuple_rows, columns=columns)

            except Exception as e:
                self._handle_exception(e)
            finally:
                pool.return_connection(connection)

    @lru_cache(maxsize=3)
    def search_table(self, table_name: str, cursor=None):
        """
        Search for a table in the Microsoft Fabric database and return the table information for similar matches.
        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                with connection.cursor() as cursor:
                    query = """
                            SELECT TABLE_NAME, COLUMN_NAME
                            FROM INFORMATION_SCHEMA.COLUMNS
                            WHERE TABLE_SCHEMA = ?
                              AND TABLE_NAME LIKE ?
                            ORDER BY TABLE_NAME, COLUMN_NAME ASC \
                            """
                    cursor.execute(query, (self.schema, f"%{table_name}%"))
                    rows = cursor.fetchall()
                    table_columns = defaultdict(list)

                    for table, column in rows:
                        table_columns[table].append(column)

                    return [
                        {"name": table, "columns": columns}
                        for table, columns in table_columns.items()
                    ]

            except Exception as e:
                self._handle_exception(e)
            finally:
                pool.return_connection(connection)

    @lru_cache(maxsize=3)
    def fetch_table_from_db(self):
        """
        Fetch all available tables from the Microsoft Fabric database.

        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                with connection.cursor() as cursor:
                    query = """
                            SELECT TABLE_NAME, COLUMN_NAME
                            FROM INFORMATION_SCHEMA.COLUMNS
                            WHERE TABLE_SCHEMA = ?
                            ORDER BY TABLE_NAME, UPPER(COLUMN_NAME) ASC \
                            """
                    cursor.execute(query, (self.schema,))

                    table_columns = defaultdict(list)
                    for table, column in cursor:
                        table_columns[table].append(column)

                    return [
                        {"name": table, "columns": columns}
                        for table, columns in table_columns.items()
                    ]

            except Exception as e:
                self._handle_exception(e)
            finally:
                pool.return_connection(connection)

    def get_ddl(self, table_name: str, cursor=None):
        """
        Get the DDL (Data Definition Language) for a table in the Microsoft Fabric database.
        :param table_name: The name of the table.
        :param cursor: [Advanced use case only] The cursor object to use for fetching the DDL. Default is None.
        :returns: `str` -> The DDL for the table.
        """
        if cursor:
            return self._fetch_ddl(table_name, cursor)
        else:
            return self._fetch_ddl_cached(table_name)

    def _fetch_ddl(self, table_name, cursor):
        """
        Fetch the DDL for a table in the Microsoft Fabric database using the passed cursor.
        Implementation for uncached response.
        """
        try:
            self._validate_identifier(table_name)
            query = """
                    SELECT COLUMN_NAME, \
                           DATA_TYPE, \
                           CHARACTER_MAXIMUM_LENGTH, \
                           IS_NULLABLE
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE TABLE_SCHEMA = ?
                      AND TABLE_NAME = ?
                    ORDER BY ORDINAL_POSITION \
                    """
            cursor.execute(query, (self.schema, table_name))
            columns = cursor.fetchall()

            if not columns:
                raise Exception(
                    f"{MSFABRIC_ERROR_MESSAGE['Table_not_found_error']}: {table_name}"
                )

            ddl_parts = [f"CREATE TABLE [{self.schema}].[{table_name}] ("]
            column_defs = []

            for col in columns:
                col_name, data_type, max_length, is_nullable = col
                col_def = f"    [{col_name}] {data_type.upper()}"

                if max_length and data_type.lower() in [
                    "varchar",
                    "nvarchar",
                    "char",
                    "nchar",
                ]:
                    col_def += f"({max_length if max_length != -1 else 'MAX'})"

                if is_nullable == "NO":
                    col_def += " NOT NULL"

                column_defs.append(col_def)

            ddl_parts.append(",\n".join(column_defs))
            ddl_parts.append(");")

            return "\n".join(ddl_parts)

        except Exception as e:
            raise Exception(f"{MSFABRIC_ERROR_MESSAGE['DDL_error']}: {e}")

    @lru_cache(maxsize=10)
    def _fetch_ddl_cached(self, table_name: str):
        """
        Fetch the DDL for a table in the Microsoft Fabric database with caching.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                with connection.cursor() as cursor:
                    result = self._fetch_ddl(table_name, cursor)
                    return result

            except Exception as e:
                raise Exception(f"{MSFABRIC_ERROR_MESSAGE['DDL_error']}: {e}")
            finally:
                pool.return_connection(connection)

    def get_table_info(self, table_names: list[str] = None, max_connections=10):
        """
        Get the table information (DDL + Sample rows) for all/specified tables in the Microsoft Fabric database.
        :param table_names: List of table names to get information (DDL + Sample rows) for. Default=None is all tables.
        :param max_connections: Maximum number of connections to be used.
                                Default is 10.
                                0 means no limit (can be dangerous).
        :returns: `str` -> The formatted table information (DDL + Sample rows).
        """

        if not table_names:
            tables = self.fetch_table_from_db()
            table_names = [item["name"] for item in tables]
        table_info = []

        if max_connections == 0:
            max_connections = len(table_names)
        else:
            max_connections = min(max_connections, len(table_names))

        def fetch_table_data(table_name, connection_pool):
            connection = connection_pool.get_connection()

            try:
                with connection.cursor() as ddl_cursor:
                    with connection.cursor() as sample_row_cursor:
                        with ThreadPoolExecutor(max_workers=2) as query_executor:
                            ddl_future = query_executor.submit(
                                self.get_ddl, table_name, ddl_cursor
                            )
                            rows_future = query_executor.submit(
                                self._get_sample_rows_query_using_cursor,
                                table_name,
                                sample_row_cursor,
                            )

                            table_ddl = ddl_future.result()
                            sample_rows = rows_future.result()

                            return "\n" + table_ddl + "\n" + sample_rows + "\n"

            except Exception as e:
                raise Exception(
                    f"{MSFABRIC_ERROR_MESSAGE['Table_fetching_data_error']}: {e}"
                )
            finally:
                connection_pool.return_connection(connection)

        with ConnectionPool(self, max_connections) as pool:
            with ThreadPoolExecutor(max_workers=max_connections) as executor:
                futures = [
                    executor.submit(fetch_table_data, table, pool)
                    for table in table_names
                ]

                for future in as_completed(futures):
                    try:
                        result = future.result()
                        table_info.append(result)
                    except Exception as err:
                        raise Exception(
                            f"{MSFABRIC_ERROR_MESSAGE['Table_fetching_data_error']}: {err}"
                        )

        return "\n".join(table_info)

    def get_sample_rows_query(self, table_name: str):
        """
        Get the sample rows query for a table in the Microsoft Fabric database.
        :param table_name: The name of the table.
        :returns: `str` -> The formatted sample rows query.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                with connection.cursor() as cursor:
                    formatted_data = self._get_sample_rows_query_using_cursor(
                        table_name, cursor
                    )
                    return str(formatted_data)
            except Exception as e:
                self._validate_identifier(table_name)
                table_identifier = f"[{self.schema}].[{table_name}]"
                raise Exception(
                    f"{MSFABRIC_ERROR_MESSAGE['Sample_rows_error']} from {table_identifier}: {e}"
                )
            finally:
                pool.return_connection(connection)

    def _get_sample_rows_query_using_cursor(self, table_name, cursor):
        """
        For internal use only: Get the sample rows query for a table in the Microsoft Fabric database using passed cursor.
        """
        self._validate_identifier(table_name)
        table_identifier = f"[{self.schema}].[{table_name}]"

        sample_rows_extraction_query = (
            f"SELECT TOP {self.no_of_sample_rows} * FROM {table_identifier}"
        )
        cursor.execute(sample_rows_extraction_query)
        column_names = [desc[0] for desc in cursor.description]
        results = cursor.fetchall()
        formatted_results = [
            f"\nSample table rows for the table: {table_identifier}",
            "\t".join(column_names),
        ]
        for row in results:
            formatted_row = "\t".join(
                [str(value) if value is not None else "None" for value in row]
            )
            formatted_results.append(formatted_row)
        formatted_data = "\n".join(formatted_results)
        return str(formatted_data)

    @staticmethod
    def _handle_exception(e):
        """
        Handle exceptions and raise custom `QueryExecutionError` based on error conditions.
        """
        args = getattr(e, "args", [])
        error_code = args[0] if len(args) > 0 else None
        error_message = args[1] if len(args) > 1 else str(e)
        msg_lower = str(error_message).lower()

        permission_keywords = ["permission", "denied", "unauthorized"]
        syntax_keywords = ["syntax", "parse", "could not find stored procedure"]
        timeout_keywords = ["timeout", "timed out"]

        if any(k in msg_lower for k in permission_keywords):
            raise QueryExecutionError(
                f"{MSFABRIC_ERROR_MESSAGE['Permission_error']} Details: {error_message}"
            )
        elif error_code == "42000" or any(k in msg_lower for k in syntax_keywords):
            raise QueryExecutionError(
                f"{MSFABRIC_ERROR_MESSAGE['SQL_syntax_error']} Original error: {error_message}"
            )
        elif any(k in msg_lower for k in timeout_keywords) or error_code in (
            "HYT00",
            "HYT01",
        ):
            raise QueryExecutionError(
                f"{MSFABRIC_ERROR_MESSAGE['Query_timeout_error']} Details: {error_message}"
            )
        else:
            raise QueryExecutionError(
                f"{MSFABRIC_ERROR_MESSAGE['Unknown_Error']} Details: {error_message}"
            )
