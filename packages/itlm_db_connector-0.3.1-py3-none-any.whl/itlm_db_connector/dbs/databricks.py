import re
from collections import defaultdict

import pandas as pd
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed

from itlm_db_connector.connection_pool import ConnectionPool
from itlm_db_connector.utils.custom_exception import (
    DatabaseConnectionError,
    QueryExecutionError,
)

DATABRICKS_DIALECT = "databricks"
DATABRICKS_QUERY_TIMEOUT_SEC = 30
DATABRICKS_SAMPLE_ROWS = 3
TOKEN_URL = "https://{hostname}/oidc/v1/token"

DATABRICKS_ERROR_MESSAGE = {
    "Databricks_Import_error": "Missing package: databricks-sql-connector. Please install it using: pip install databricks-sql-connector",
    "Azure_Import_error": "Missing package: azure-identity. Please install it using: pip install azure-identity",
    "Connection_error": "ERR_NO_CONNECTION_CONFIG: Missing required connection configuration for Databricks",
    "Invalid_endpoint_error": "ERR_ENDPOINT_INVALID: Connection test failed for Databricks",
    "Databricks_Authentication_error": "ERR_AUTH_FAILED: Authentication failed, Failed to acquire Databricks OAuth token",
    "Authentication_error": "ERR_AUTH_FAILED: Authentication failed",
    "Permission_error": "ERR_DATABRICKS_PERMISSION: Insufficient permissions.",
    "SQL_syntax_error": "ERR_SQL_SYNTAX: Syntax error in query.",
    "Query_timeout_error": "ERR_QUERY_TIMEOUT: Query execution timed out.",
    "Unknown_Error": "ERR_UNKNOWN_DATABRICKS: Unknown Databricks error",
    "Table_not_found_error": "Table not found in the database.",
    "Table_fetching_data_error": "Error fetching table data",
    "Sample_rows_error": "Error getting sample rows",
    "DDL_error": "Error getting DDL",
    "Value_error": "Invalid identifier",
}


class DataBricks:
    dialect = DATABRICKS_DIALECT

    def __init__(
        self,
        **kwargs,
    ) -> None:
        """
        Initialize the Databricks connector object using kwargs.
        This function maps internal parameters to corresponding environment-like values
        from the kwargs dictionary (which can contain `username`, `password`, etc.).

        kwargs can include:
            - username (maps to client_id)
            - password (maps to client_secret)
            - host (maps to server_hostname)
            - warehouse (maps to http_path)
            - database (maps to catalog)
            - schema (maps to schema)
            - query_timeout
            - no_of_sample_rows
        """
        if not kwargs.get("host") or not kwargs.get("warehouse"):
            raise DatabaseConnectionError(DATABRICKS_ERROR_MESSAGE["Connection_error"])

        if not (kwargs.get("username") and kwargs.get("password")):
            raise DatabaseConnectionError(DATABRICKS_ERROR_MESSAGE["Connection_error"])

        self.client_id = kwargs.get("username")
        self.client_secret = kwargs.get("password")
        self.server_hostname = kwargs.get("host")
        self.http_path = kwargs.get("warehouse")
        self.catalog = kwargs.get("database")
        self.schema = kwargs.get("schema")
        self.query_timeout = DATABRICKS_QUERY_TIMEOUT_SEC
        self.no_of_sample_rows = DATABRICKS_SAMPLE_ROWS

        if self.catalog:
            self._validate_identifier(self.catalog)
        if self.schema:
            self._validate_identifier(self.schema)

    @staticmethod
    def _validate_identifier(name):
        identifier = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
        if not identifier.match(name):
            raise ValueError(f"{DATABRICKS_ERROR_MESSAGE['Value_error']}: {name}")
        return name

    def _get_databricks_oauth_token(self):
        """
        Acquire a Databricks OAuth M2M token using client credentials directly from Databricks OIDC endpoint.

        Returns:
            str: Access token for Databricks authentication
        """
        import requests

        try:
            token_url = TOKEN_URL.format(hostname=self.server_hostname)

            data = {"grant_type": "client_credentials", "scope": "all-apis"}

            auth = (self.client_id, self.client_secret)

            response = requests.post(token_url, data=data, auth=auth, timeout=30)
            response.raise_for_status()
            token_data = response.json()
            return token_data["access_token"]

        except Exception as e:
            raise DatabaseConnectionError(
                f"{DATABRICKS_ERROR_MESSAGE['Databricks_Authentication_error']}: {str(e)}"
            )

    def create_connection(self):
        """
        Establish and return a connection to Databricks using the Databricks SQL Connector.
        Supports both Personal Access Token and OAuth 2.0 Service Principal authentication.
        Executes a simple test query to validate the connection.
        Raises:
            DatabaseConnectionError with specific error codes:
                ERR_AUTH_FAILED
                ERR_ENDPOINT_INVALID
                ERR_UNKNOWN_DATABRICKS
        Returns:
            databricks.sql.client.Connection: Authenticated connection object.
        """
        try:
            from databricks import sql
        except ImportError:
            raise ImportError(DATABRICKS_ERROR_MESSAGE["Databricks_Import_error"])

        try:
            token = self._get_databricks_oauth_token()
            connection = sql.connect(
                server_hostname=self.server_hostname,
                http_path=self.http_path,
                access_token=token,
                catalog=self.catalog,
                schema=self.schema,
                _socket_timeout=self.query_timeout,
            )
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
                result = cursor.fetchone()
                if not result or result[0] != 1:
                    connection.close()
                    raise DatabaseConnectionError(
                        DATABRICKS_ERROR_MESSAGE["Invalid_endpoint_error"]
                    )

            return connection

        except Exception as e:
            error_str = str(e).lower()

            auth_keywords = ["authentication", "token", "unauthorized"]
            endpoint_keywords = ["hostname", "http_path", "connection"]

            if any(k in error_str for k in auth_keywords):
                raise DatabaseConnectionError(
                    f"{DATABRICKS_ERROR_MESSAGE['Authentication_error']}: {e}"
                )

            elif any(k in error_str for k in endpoint_keywords):
                raise DatabaseConnectionError(
                    f"{DATABRICKS_ERROR_MESSAGE['Invalid_endpoint_error']}: {e}"
                )

            else:
                raise DatabaseConnectionError(
                    f"{DATABRICKS_ERROR_MESSAGE['Unknown_Error']}: {e}"
                )

    def execute_query(self, query: str):
        """
        Execute the SQL query on the Databricks database.
        :param query: The SQL query to execute.
        :returns: pandas.DataFrame
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                with connection.cursor() as cursor:
                    cursor.execute(query)
                    rows = cursor.fetchall()
                    columns = (
                        [col[0] for col in cursor.description]
                        if cursor.description
                        else []
                    )

                    if rows and columns:
                        tuple_rows = [
                            tuple(
                                row[i] if i < len(row) else None
                                for i in range(len(columns))
                            )
                            for row in rows
                        ]
                    else:
                        tuple_rows = rows

                    return pd.DataFrame(tuple_rows, columns=columns)

            except Exception as e:
                self._handle_exception(e)
            finally:
                pool.return_connection(connection)

    @lru_cache(maxsize=3)
    def search_table(self, table_name: str, cursor=None):
        """
        Search for a table in the Databricks catalog and return the table information for similar matches.
        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                with connection.cursor() as cursor:
                    query = """
                        SELECT table_name, column_name
                        FROM {}.information_schema.columns
                        WHERE table_schema = :schema
                          AND table_name LIKE :table_pattern
                        ORDER BY table_name, column_name ASC
                    """.format(self.catalog)
                    cursor.execute(
                        query,
                        {"schema": self.schema, "table_pattern": f"%{table_name}%"},
                    )
                    rows = cursor.fetchall()
                    table_columns = defaultdict(list)

                    for table, column in rows:
                        table_columns[table].append(column)

                    return [
                        {"name": table, "columns": columns}
                        for table, columns in table_columns.items()
                    ]

            except Exception as e:
                self._handle_exception(e)
            finally:
                pool.return_connection(connection)

    @lru_cache(maxsize=3)
    def fetch_table_from_db(self):
        """
        Fetch all available tables from the Databricks catalog.
        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                with connection.cursor() as cursor:
                    query = """
                        SELECT table_name, column_name
                        FROM {}.information_schema.columns
                        WHERE table_schema = :schema
                        ORDER BY table_name, UPPER(column_name) ASC
                    """.format(self.catalog)
                    cursor.execute(query, {"schema": self.schema})

                    table_columns = defaultdict(list)
                    for table, column in cursor:
                        table_columns[table].append(column)

                    return [
                        {"name": table, "columns": columns}
                        for table, columns in table_columns.items()
                    ]

            except Exception as e:
                self._handle_exception(e)
            finally:
                pool.return_connection(connection)

    def get_ddl(self, table_name: str, cursor=None):
        """
        Get the DDL (Data Definition Language) for a table in the Databricks catalog.
        :param table_name: The name of the table.
        :param cursor: [Advanced usecase only] The cursor object to use for fetching the DDL. Default is None.
        :returns: `str` -> The DDL for the table.
        """
        if cursor:
            return self._fetch_ddl(table_name, cursor)
        else:
            return self._fetch_ddl_cached(table_name)

    def _fetch_ddl(self, table_name, cursor):
        """
        Fetch the DDL for a table in the Databricks catalog using the passed cursor.
        Implementation for uncached response.
        """
        try:
            self._validate_identifier(table_name)
            query = f"SHOW CREATE TABLE {self.catalog}.{self.schema}.{table_name}"
            cursor.execute(query)
            result = cursor.fetchone()
            if not result:
                raise Exception(
                    f"{DATABRICKS_ERROR_MESSAGE['Table_not_found_error']}: {table_name}"
                )

            return str(result[0])
        except Exception as e:
            raise Exception(f"{DATABRICKS_ERROR_MESSAGE['DDL_error']}: {e}")

    @lru_cache(maxsize=10)
    def _fetch_ddl_cached(self, table_name: str):
        """
        Fetch the DDL for a table in the Databricks catalog with caching.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                with connection.cursor() as cursor:
                    self._validate_identifier(table_name)
                    query = (
                        f"SHOW CREATE TABLE {self.catalog}.{self.schema}.{table_name}"
                    )
                    cursor.execute(query)
                    result = cursor.fetchone()
                    if not result:
                        raise Exception(
                            f"{DATABRICKS_ERROR_MESSAGE['Table_not_found_error']}: {table_name}"
                        )
                    return str(result[0])

            except Exception as e:
                raise Exception(f"{DATABRICKS_ERROR_MESSAGE['DDL_error']}: {e}")
            finally:
                pool.return_connection(connection)

    def get_table_info(self, table_names: list[str] = None, max_connections=10):
        """
        Get the table information (DDL + Sample rows) for all/specified tables in the Databricks catalog.
        :param table_names: List of table names to get information (DDL + Sample rows) for. Default=None is all tables.
        :param max_connections: Maximum number of connections to be used.
                                Default is 10.
                                0 means no limit (can be dangerous).
        :returns: `str` -> The formatted table information (DDL + Sample rows).
        """

        if not table_names:
            tables = self.fetch_table_from_db()
            table_names = [item["name"] for item in tables]
        table_info = []

        if max_connections == 0:
            max_connections = len(table_names)
        else:
            max_connections = min(max_connections, len(table_names))

        def fetch_table_data(table_name, connection_pool):
            connection = connection_pool.get_connection()

            try:
                with (
                    connection.cursor() as ddl_cursor,
                    connection.cursor() as sample_row_cursor,
                ):
                    with ThreadPoolExecutor(max_workers=2) as query_executor:
                        ddl_future = query_executor.submit(
                            self.get_ddl, table_name, ddl_cursor
                        )
                        rows_future = query_executor.submit(
                            self._get_sample_rows_query_using_cursor,
                            table_name,
                            sample_row_cursor,
                        )

                        table_ddl = ddl_future.result()
                        sample_rows = rows_future.result()

                        return "\n" + table_ddl + "\n" + sample_rows + "\n"

            except Exception as e:
                raise Exception(
                    f"{DATABRICKS_ERROR_MESSAGE['Table_fetching_data_error']}: {e}"
                )
            finally:
                connection_pool.return_connection(connection)

        with ConnectionPool(self, max_connections) as pool:
            with ThreadPoolExecutor(max_workers=max_connections) as executor:
                futures = [
                    executor.submit(fetch_table_data, table, pool)
                    for table in table_names
                ]

                for future in as_completed(futures):
                    try:
                        result = future.result()
                        table_info.append(result)
                    except Exception as err:
                        raise Exception(
                            f"{DATABRICKS_ERROR_MESSAGE['Table_fetching_data_error']}: {err}"
                        )

        return "\n".join(table_info)

    def get_sample_rows_query(self, table_name: str):
        """
        Get the sample rows query for a table in the Databricks catalog.
        :param table_name: The name of the table.
        :returns: `str` -> The formatted sample rows query.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                with connection.cursor() as cursor:
                    formatted_data = self._get_sample_rows_query_using_cursor(
                        table_name, cursor
                    )
                    return str(formatted_data)
            except Exception as e:
                self._validate_identifier(table_name)
                table_identifier = f"{self.catalog}.{self.schema}.{table_name}"
                raise Exception(
                    f"{DATABRICKS_ERROR_MESSAGE['Sample_rows_error']} from {table_identifier}: {e}"
                )

            finally:
                pool.return_connection(connection)

    def _get_sample_rows_query_using_cursor(self, table_name, cursor):
        """
        For internal use only: Get the sample rows query for a table in the Databricks catalog using passed cursor.
        """
        self._validate_identifier(table_name)
        table_identifier = f"{self.catalog}.{self.schema}.{table_name}"

        sample_rows_extraction_query = (
            f"SELECT * FROM {table_identifier} LIMIT {self.no_of_sample_rows}"
        )
        cursor.execute(sample_rows_extraction_query)
        column_names = [desc[0] for desc in cursor.description]
        results = cursor.fetchall()
        formatted_results = [
            f"\nSample table rows for the table: {table_identifier}",
            "\t".join(column_names),
        ]
        for row in results:
            formatted_row = "\t".join(
                [str(value) if value is not None else "None" for value in row]
            )
            formatted_results.append(formatted_row)
        formatted_data = "\n".join(formatted_results)
        return str(formatted_data)

    @staticmethod
    def _handle_exception(e):
        """
        Handle exceptions and raise custom `QueryExecutionError` based on error conditions.
        """
        error_message = str(e)
        msg_lower = error_message.lower()
        permission_keywords = ["permission", "denied", "unauthorized"]
        syntax_keywords = ["syntax", "parse", "semantic"]
        timeout_keywords = ["timeout", "timed out"]

        if any(k in msg_lower for k in permission_keywords):
            raise QueryExecutionError(
                f"{DATABRICKS_ERROR_MESSAGE['Permission_error']} Details: {error_message}"
            )
        elif any(k in msg_lower for k in syntax_keywords):
            raise QueryExecutionError(
                f"{DATABRICKS_ERROR_MESSAGE['SQL_syntax_error']} Original error: {error_message}"
            )
        elif any(k in msg_lower for k in timeout_keywords):
            raise QueryExecutionError(
                f"{DATABRICKS_ERROR_MESSAGE['Query_timeout_error']} Details: {error_message}"
            )
        else:
            raise QueryExecutionError(
                f"{DATABRICKS_ERROR_MESSAGE['Unknown_Error']} Details: {error_message}"
            )
