import os
from calendar import c
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import lru_cache

import pandas as pd

from itlm_db_connector.base import Database
from itlm_db_connector.connection_pool import ConnectionPool
from itlm_db_connector.utils.custom_exception import (DatabaseConnectionError,
                                                      QueryExecutionError)


class BigQuery(Database):
    dialect = "bigquery"

    def __init__(
            self,
            private_key: str,
            database: str = None,
            warehouse: str = None,
            no_of_sample_rows: int = None,
            **kwargs,
    ):
        """
        Initialize the BigQuery database connection using DB API.

        Required parameters:
            :param private_key: String containing the service account key in JSON format.
            :param database (or dataset): The BigQuery dataset.
            :param warehouse (or project): The GCP project ID.
        Optional parameters:
            :param no_of_sample_rows: Number of sample rows to fetch. Default is 5.
        """
        try:
            from json import loads

            from google.cloud import bigquery
            from google.cloud.bigquery.dbapi import connect  # noqa: F401
            from google.oauth2 import service_account
        except ImportError:
            raise ImportError(
                "Please install the 'bigquery.dbapi' package to use this connector."
            )
        self.no_of_sample_rows = no_of_sample_rows if no_of_sample_rows else 5
        self.dataset = database or kwargs.get("dataset")
        self.project = warehouse or kwargs.get("project")
        if not self.dataset or not self.project:
            raise ValueError(
                "Both 'dataset' and 'project' parameters are required for BigQuery."
            )
        self.service_account_key = loads(private_key)

        # Although location is not used with DB API queries, we keep it for compatibility.
        # self.location = kwargs.get("location", "US")

    def create_connection(self):
        """
        For BigQuery DB API, the connection object is created via connect().
        :returns: A DB API connection.
        """
        try:
            from google.cloud import bigquery
            from google.cloud.bigquery.dbapi import connect
            from google.oauth2 import service_account
        except ImportError:
            raise ImportError(
                "Please install the 'bigquery.dbapi' package to use this connector."
            )
        try:
            self.credentials = service_account.Credentials.from_service_account_info(
                self.service_account_key
            )
            client = bigquery.Client(credentials=self.credentials, project=self.project)
            connection = connect(client=client)
        except Exception as e:
            raise DatabaseConnectionError(f"Error connecting to BigQuery: {str(e)}")
        return connection

    @lru_cache(maxsize=3)
    def fetch_table_from_db(self):
        """
        Fetch all available tables from the dataset by querying INFORMATION_SCHEMA.TABLES.
        :returns: A list of dictionaries each containing:
                  - name (str): The table name.
                  - columns (list[str]): Sorted list of column names.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                query_tables = f"SELECT table_name FROM `{self.project}.{self.dataset}.INFORMATION_SCHEMA.TABLES`"
                cursor.execute(query_tables)
                table_rows = cursor.fetchall()
                table_info = []
                for row in table_rows:
                    table_name = row[0]
                    # For each table, get its column names.
                    query_columns = f"SELECT column_name FROM {self.project}.{self.dataset}.INFORMATION_SCHEMA.COLUMNS WHERE table_name = '{table_name}' ORDER BY ordinal_position"
                    cursor.execute(query_columns)
                    col_rows = cursor.fetchall()
                    columns = sorted(
                        [col[0] for col in col_rows], key=lambda col: col.upper()
                    )
                    table_info.append({"name": table_name, "columns": columns})
                return table_info
            except Exception as e:
                raise DatabaseConnectionError(
                    f"Error fetching table information from BigQuery: {str(e)}"
                )
            finally:
                if cursor is not None:  # Close cursor only if it was created
                    cursor.close()
                pool.return_connection(connection)

    @lru_cache(maxsize=3)
    def search_table(self, table_name: str):
        """
        Search for tables in the dataset by name.
        :param table_name: The (partial) table name to search for.
        :returns: List of table metadata dictionaries.
        """
        if not table_name:
            raise ValueError("Table name is required.")
        tables = self.fetch_table_from_db()
        matched = [
            table for table in tables if table_name.lower() in table["name"].lower()
        ]
        return matched

    def get_ddl(self, table_name: str, cursor=None):
        """
        Get a simulated DDL (CREATE TABLE statement) for a table by fetching column metadata.
        :param table_name: The table name.
        :param cursor: [Advanced use case only] The cursor object to use for fetching the DDL. Default is None.
        :returns: A string containing the CREATE TABLE statement (The DDL for the table).
        """
        if cursor:
            return self._fetch_ddl(table_name, cursor)
        else:
            return self._fetch_ddl_cached(table_name)

    def _fetch_ddl(self, table_name: str, cursor):
        """
        Internal method to fetch the DDL for a table using INFORMATION_SCHEMA.COLUMNS.
        :returns: A string representing the CREATE TABLE statement.
        """
        try:
            query = (
                f"SELECT column_name, data_type FROM `{self.project}.{self.dataset}.INFORMATION_SCHEMA.COLUMNS` "
                f"WHERE table_name = '{table_name}' ORDER BY ordinal_position"
            )
            cursor.execute(query)
            columns_info = cursor.fetchall()
            if not columns_info:
                raise Exception(f"Table {table_name} not found in the database.")
            ddl = f"CREATE TABLE {table_name} (\n"
            ddl += ",\n".join([f"    {col[0]} {col[1]}" for col in columns_info])
            ddl += "\n);"
            return ddl
        except Exception as e:
            raise Exception(f"Error getting DDL for table {table_name}: {str(e)}")
        finally:
            cursor.close()

    @lru_cache(maxsize=10)
    def _fetch_ddl_cached(self, table_name: str):
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                return self._fetch_ddl(table_name, cursor)
            finally:
                pool.return_connection(connection)

    def execute_query(self, query: str):
        """
        Execute the SQL query on BigQuery using the BigQuery Client and return the result as a pandas DataFrame.
        :param query: The SQL query to execute.
        :returns: pandas.DataFrame with query results.
        """
        try:
            from google.cloud import bigquery
        except ImportError:
            raise ImportError(
                "Please install the 'bigquery' package to use this connector."
            )
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                project_dataset = bigquery.DatasetReference(self.project, self.dataset)

                job_config = bigquery.QueryJobConfig(default_dataset=project_dataset)
                cursor.execute(query, job_config=job_config)
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                print(rows, "\n\n cols: \n\n", columns)
                data = [tuple(r) for r in rows]

                return pd.DataFrame(data, columns=columns)

            except Exception as e:
                raise QueryExecutionError(f"Error executing query: {str(e)}")
            finally:
                if cursor is not None:  # Close cursor only if it was created
                    cursor.close()
                pool.return_connection(connection)

    def get_table_info(self, table_names: list[str] = None, max_connections=10):
        """
        Get table information (DDL plus sample rows) for specified or all tables.
        :param table_names: List of table names; if None, all tables in the dataset are processed.
        :param max_connections: Maximum number of threads to use.
        :returns: A formatted string containing table DDL and sample rows.
        """
        if table_names is None or not table_names:
            tables = self.fetch_table_from_db()
            table_names = [table["name"] for table in tables]
        table_info = []
        if max_connections == 0:
            max_connections = len(table_names)
        else:
            max_connections = min(max_connections, len(table_names))

        def fetch_table_data(table_name, connection_pool):
            connection = connection_pool.get_connection()
            try:
                with ThreadPoolExecutor(max_workers=2) as executor:
                    ddl_future = executor.submit(
                        self.get_ddl, table_name, connection.cursor()
                    )
                    rows_future = executor.submit(
                        self._get_sample_rows_query_using_cursor,
                        table_name,
                        connection.cursor(),
                    )
                    table_ddl = ddl_future.result()
                    sample_rows = rows_future.result()
                    return f"\n{table_ddl}\n{sample_rows}\n"
            except Exception as e:
                raise Exception(f"Error fetching table data for {table_name}: {e}")
            finally:
                connection_pool.return_connection(connection)

        with ConnectionPool(self, max_connections) as pool:
            with ThreadPoolExecutor(max_workers=max_connections) as executor:
                futures = [
                    executor.submit(fetch_table_data, table, pool)
                    for table in table_names
                ]
                for future in as_completed(futures):
                    try:
                        result = future.result()
                        table_info.append(result)
                    except Exception as err:
                        raise Exception(f"Error fetching table data: {err}")
        return "\n".join(table_info)

    def get_sample_rows_query(self, table_name: str):
        """
        Get a formatted string of sample rows for a given table using DB API.
        :param table_name: The table name.
        :returns: A string with the sample rows.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                formatted_data = self._get_sample_rows_query_using_cursor(
                    table_name, cursor
                )
                return str(formatted_data)
            except Exception as e:
                table_identifier = f"{self.dataset}.{table_name}"
                raise Exception(
                    f"Error getting sample rows from {table_identifier}: {e}"
                )
            finally:
                pool.return_connection(connection)

    def _get_sample_rows_query_using_cursor(self, table_name: str, cursor):
        """
        Internal method to fetch and format sample rows from a table using DB API.
        :returns: A formatted string showing column names and sample rows.
        """
        try:
            query = f"SELECT * FROM `{self.project}.{self.dataset}.{table_name}` LIMIT {self.no_of_sample_rows}"
            cursor.execute(query)
            rows = cursor.fetchall()
            columns = (
                [desc[0] for desc in cursor.description] if cursor.description else []
            )
            formatted_results = [
                f"Sample rows for table: {self.project}.{self.dataset}.{table_name}"
            ]
            if columns:
                formatted_results.append("\t".join(columns))
            for row in rows:
                row_dict = dict(zip(columns, row))
                formatted_results.append(
                    "\t".join([str(row_dict.get(col, "None")) for col in columns])
                )
            cursor.close()
            return "\n".join(formatted_results)
        except Exception as e:
            raise Exception(f"Error getting sample rows for table {table_name}: {e}")
